<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ConjunctionController extends Controller
{
    public function index()
    {
        return view('materi.conjunction');
    }
}
