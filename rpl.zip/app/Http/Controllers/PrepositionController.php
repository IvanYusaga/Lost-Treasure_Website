<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PrepositionController extends Controller
{
    public function index()
    {
        return view('materi.preposition');
    }
}
