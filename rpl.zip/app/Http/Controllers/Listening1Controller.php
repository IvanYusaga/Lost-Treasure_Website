<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Listening1Controller extends Controller
{
    public function index()
    {
        return view('gamestage.listening.listening1');
    }
}
