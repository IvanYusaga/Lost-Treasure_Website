<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pilih Stage</title>
    <link rel="stylesheet" href="{{ asset('css/choose-stage.css') }}">
</head>
<body>
    <div class="container">
        @yield('container')
    </div>
</body>
</html>