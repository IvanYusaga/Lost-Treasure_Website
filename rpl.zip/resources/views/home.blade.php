@extends('layout.home')

@section('content')
<div class="home">
        <div class="start">
            <button type="submit" onclick="window.location.href='/choose'">Start</button>
        </div>
</div>
@endsection
