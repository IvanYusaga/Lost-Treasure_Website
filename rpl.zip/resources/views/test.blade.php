@extends('layout.test')

@section('container')
    <div class="materi">
        <button type="submit" onclick="window.location.href='/choosemateri'"> Materi </button>
    </div>
</div>
    <div class="soal">
        <button type="submit" onclick="window.location.href='#'"> Soal </button>
    </div>
@endsection