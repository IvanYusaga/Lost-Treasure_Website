<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pilih Opsi</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/afterlogin.css')); ?>">
</head>
<body>
    <div class="container">
        <?php echo $__env->yieldContent('container'); ?>
    </div>
</body>
</html><?php /**PATH D:\Tugas\Semester 4\Rekayasa Perangkat Lunak\UAS\app1-laravel\resources\views/layout/afterlogin.blade.php ENDPATH**/ ?>