

<?php $__env->startSection('content'); ?>
<div class="login-box">
    <div class="form-input">
        <button type="submit" onclick="window.location.href='/login'">Login</button>
    </div>
    <p> Or </p>
    <div class="form-input">
        <button type="submit" onclick="window.location.href='/register'">Register</button>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Tugas\Semester 4\Rekayasa Perangkat Lunak\Laravel App\app1-laravel\resources\views/afterplay.blade.php ENDPATH**/ ?>