<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Conjunction</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/materi/conjunction.css')); ?>">
</head>
<body>
    <div class="image-container">
        <?php echo $__env->yieldContent('image-container'); ?>
    </div>
</body>
</html><?php /**PATH D:\Tugas\Semester 4\Rekayasa Perangkat Lunak\Laravel App\app1-laravel\resources\views/layout/materi/conjunction.blade.php ENDPATH**/ ?>