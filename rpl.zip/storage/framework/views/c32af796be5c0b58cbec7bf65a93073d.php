

<?php $__env->startSection('materi-container'); ?>
    <div class="materi materi1">
        <a href="/tenses"><img src="<?php echo e(asset('image/materi/tenses_new.png')); ?>" alt="Tenses"></a>
    </div>
    <div class="materi materi2">
        <a href="/passive-voice"><img src="<?php echo e(asset('image/materi/pasivevoice_new.png')); ?>" alt="Passive Voice"></a>
    </div>
    <div class="materi materi3">
        <a href="/preposition"><img src="<?php echo e(asset('image/materi/preposition_new.png')); ?>" alt="Preposition"></a>
    </div>
    <div class="materi materi4">
        <a href="/conjunction"><img src="<?php echo e(asset('image/materi/conjunction_new.png')); ?>" alt="Conjunction"></a>
    </div>
    <div class="button-back">
        <a href="/afterlogin">
            <img src=<?php echo e(asset('image/game-stage/button-back.png')); ?> alt="">
        </a>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.materi.choosemateri', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Tugas\Semester 4\Rekayasa Perangkat Lunak\Laravel App\app1-laravel\resources\views/materi/choosemateri.blade.php ENDPATH**/ ?>