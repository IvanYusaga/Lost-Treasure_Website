

<?php $__env->startSection('content'); ?>
<div class="home">
        <div class="start">
            <button type="submit" onclick="window.location.href='/choose'">Start</button>
        </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Tugas\Semester 4\Rekayasa Perangkat Lunak\UAS\app1-laravel\resources\views/home.blade.php ENDPATH**/ ?>