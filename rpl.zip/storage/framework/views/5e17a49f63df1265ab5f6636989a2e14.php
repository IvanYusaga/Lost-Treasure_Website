

<?php $__env->startSection('container'); ?>
    <h2>Choose Your Level</h2>
    <div class="stage">
        <div class="stage1">
            <button type="submit" onclick="window.location.href='#'">1</button>
        </div>
        <div class="stage2">
            <button type="submit" onclick="window.location.href='#'">2</button>
        </div>
        <div class="stage3">
            <button type="submit" onclick="window.location.href='#'">3</button>
        </div>
    </div>
    <div class="button-back">
        <a href="/choose-stage">
            <img src=<?php echo e(asset('image/game-stage/choose-level-1/button-back.png')); ?> alt="">
        </a>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.game-stage.choose-level', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Tugas\Semester 4\Rekayasa Perangkat Lunak\Laravel App\app1-laravel\resources\views/gamestage/choose-level/choose-level-1.blade.php ENDPATH**/ ?>